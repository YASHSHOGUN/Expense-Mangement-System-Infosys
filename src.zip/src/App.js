 

import React from 'react';
import ReactDOM from 'react-dom';
import AppLayout from './component/AppLayout';

ReactDOM.render(<AppLayout />, document.getElementById('root'));
