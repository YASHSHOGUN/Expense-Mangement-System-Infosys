import React, { useState } from "react";
import { useNavigate } from "react-router-dom";  

 
class Employee {
  constructor(id, name, age, position, department, email) {
    this.id = id;
    this.name = name;
    this.age = age;
    this.position = position;
    this.department = department;
    this.email = email;
  }
}

 
const EmployeeService = {
  createEmployee: async (employee) => {
  
    return new Promise((resolve, reject) => {
      setTimeout(() => {
      
        resolve("Employee created successfully!");
      }, 1000);
    });
  }
};

const Register = () => {
  const navigate = useNavigate();  
  const [employee, setEmployee] = useState(new Employee(0, '', 0, '', '', ''));
  const [message, setMessage] = useState('');
 
  const styles = {
    container: {
      padding: '20px',
      maxWidth: '400px',
      margin: '0 auto',
      border: '1px solid #ccc',
      borderRadius: '4px',
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    },
    input: {
      width: '100%',
      padding: '10px',
      margin: '10px 0',
      border: '1px solid #ccc',
      borderRadius: '4px',
    },
    button: {
      width: '100%',
      padding: '10px',
      backgroundColor: '#4CAF50',
      color: 'white',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
    },
    message: {
      marginTop: '10px',
      color: 'red',
    },
    linkButton: {
      backgroundColor: '#008CBA',
    },
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEmployee((prevEmployee) => ({
      ...prevEmployee,
      [name]: value,
    }));
  };

  const createEmployee = async () => {
    try {
      const response = await EmployeeService.createEmployee(employee);
      setMessage(response);
      setEmployee(new Employee(0, '', 0, '', '', ''));  
    } catch (error) {
      console.error(error);
      setMessage('Unable to save! Contact Admin');
    }
  };

  return (
    <div style={styles.container}>
      <h2>Employee Registration</h2>
      <input
        style={styles.input}
        type="text"
        name="name"
        placeholder="Name"
        value={employee.name}
        onChange={handleChange}
      />
      <input
        style={styles.input}
        type="number"
        name="age"
        placeholder="Age"
        value={employee.age}
        onChange={handleChange}
      />
      <input
        style={styles.input}
        type="text"
        name="position"
        placeholder="Position"
        value={employee.position}
        onChange={handleChange}
      />
      <input
        style={styles.input}
        type="text"
        name="department"
        placeholder="Department"
        value={employee.department}
        onChange={handleChange}
      />
      <input
        style={styles.input}
        type="email"
        name="email"
        placeholder="Email"
        value={employee.email}
        onChange={handleChange}
      />
      <button style={styles.button} onClick={createEmployee}>
        Register
      </button>
      {message && <div style={styles.message}>{message}</div>}
      
      <button
        style={{ ...styles.button, ...styles.linkButton }} 
        onClick={() => navigate("/login")} 
      >
        Go to Login
      </button>
    </div>
  );
};

export default Register;
