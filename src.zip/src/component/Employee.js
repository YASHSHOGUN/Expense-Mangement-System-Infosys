class Employee {
    constructor(empId, empName, empSal, empGen, empDept, empAddr) {
      this.empId = empId;
      this.empName = empName;
      this.empSal = empSal;
      this.empGen = empGen;
      this.empDept = empDept;
      this.empAddr = empAddr;
    }
  }
  
 