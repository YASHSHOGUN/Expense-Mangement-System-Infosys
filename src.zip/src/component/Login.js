import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';  
 
const AuthService = {
  login: async (credentials) => {
 
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (credentials.email === 'test@example.com' && credentials.password === 'password') {
          resolve("Login successful!");
        } else {
          reject("Invalid email or password");
        }
      }, 1000);
    });
  }
};

const Login = () => {
  const navigate = useNavigate();  
  const [credentials, setCredentials] = useState({ email: '', password: '' });
  const [message, setMessage] = useState('');
 
  const styles = {
    container: {
      padding: '20px',
      maxWidth: '400px',
      margin: '0 auto',
      border: '1px solid #ccc',
      borderRadius: '4px',
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    },
    input: {
      width: '100%',
      padding: '10px',
      margin: '10px 0',
      border: '1px solid #ccc',
      borderRadius: '4px',
    },
    button: {
      width: '100%',
      padding: '10px',
      backgroundColor: '#4CAF50',
      color: 'white',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
    },
    message: {
      marginTop: '10px',
      color: 'red',
    },
    linkButton: {
      backgroundColor: '#008CBA',
      marginTop: '10px',
    },
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCredentials((prevCredentials) => ({
      ...prevCredentials,
      [name]: value,
    }));
  };

  const handleLogin = async () => {
    try {
      const response = await AuthService.login(credentials);
      setMessage(response);
      setCredentials({ email: '', password: '' });  
    } catch (error) {
      console.error(error);
      setMessage(error);
    }
  };

  return (
    <div style={styles.container}>
      <h2>Login</h2>
      <input
        style={styles.input}
        type="email"
        name="email"
        placeholder="Email"
        value={credentials.email}
        onChange={handleChange}
      />
      <input
        style={styles.input}
        type="password"
        name="password"
        placeholder="Password"
        value={credentials.password}
        onChange={handleChange}
      />
      <button style={styles.button} onClick={handleLogin}>
        Login
      </button>
      {message && <div style={styles.message}>{message}</div>}
      
      <button
        style={{ ...styles.button, ...styles.linkButton }} 
        onClick={() => navigate("/register")}  
      >
        New User
      </button>
    </div>
  );
};

export default Login;
